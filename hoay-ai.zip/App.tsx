import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import ChatView from './components/ChatView';
import ImageGeneratorView from './components/ImageGeneratorView';
import RemindersView from './components/RemindersView';
import VideoCreatorView from './components/VideoCreatorView';
import { View } from './types';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>(View.CHAT);

  const renderView = () => {
    switch (activeView) {
      case View.CHAT:
        return <ChatView />;
      case View.IMAGE:
        return <ImageGeneratorView />;
      case View.VIDEO:
        return <VideoCreatorView />;
      case View.REMINDERS:
        return <RemindersView />;
      default:
        return <ChatView />;
    }
  };

  return (
    <div className="h-screen w-screen bg-gray-900 text-white flex overflow-hidden">
      <Sidebar activeView={activeView} setActiveView={setActiveView} />
      <main className="flex-1 h-full flex flex-col">
        <div className="w-full h-40 flex-shrink-0 relative">
            <img
                src="https://static.wixstatic.com/media/c80039_8696d301ec0b4a869f1b2ad3a417b8e9~mv2.jpg/v1/fill/w_1901,h_861,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/c80039_8696d301ec0b4a869f1b2ad3a417b8e9~mv2.jpg"
                alt="A diverse group of happy seniors enjoying various activities."
                className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/40 flex items-center justify-start p-6 md:p-8">
                <img
                    src="https://static.wixstatic.com/media/c80039_2ff0674dfd1b425c8e174ffc55193ea3~mv2.png/v1/fill/w_134,h_168,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/HOAY%20LOGO.png"
                    alt="HOAY AI Logo"
                    className="h-20 md:h-24 w-auto flex-shrink-0"
                />
            </div>
        </div>
        {renderView()}
      </main>
    </div>
  );
};

export default App;