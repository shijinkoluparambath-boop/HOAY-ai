
export const POSITIVE_MESSAGES: string[] = [
    "Every day is a new beginning. Take a deep breath, smile, and start again.",
    "You are capable of amazing things. Believe in yourself.",
    "Your presence is a gift to the world. Shine on!",
    "Age is just a number. Your wisdom and experience are your treasures.",
    "The best is yet to come. Embrace the journey.",
    "A smile is a curve that sets everything straight. Share yours today!",
    "You have the power to create a beautiful story. Make today a great chapter.",
    "Stay positive, work hard, and make it happen."
];
