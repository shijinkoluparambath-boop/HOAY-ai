
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Role, type ChatMessage, type GroundingSource } from '../types';
import { startChat, sendMessageStream, getGroundedResponseStream, extractSources } from '../services/geminiService';
import { POSITIVE_MESSAGES } from '../constants';
import { SendIcon } from './Icons';
import type { Chat, GenerateContentResponse } from '@google/genai';

const UserMessage: React.FC<{ text: string }> = ({ text }) => (
  <div className="flex justify-end mb-4">
    <div className="mr-2 py-3 px-4 bg-blue-500 rounded-bl-3xl rounded-tl-3xl rounded-tr-xl text-white max-w-lg">
      {text}
    </div>
  </div>
);

const AiMessage: React.FC<{ message: ChatMessage }> = ({ message }) => (
    <div className="flex justify-start mb-4">
        <div className="ml-2 py-3 px-4 bg-gray-700 rounded-br-3xl rounded-tr-3xl rounded-tl-xl text-gray-200 max-w-lg">
            <p className="whitespace-pre-wrap">{message.text}</p>
            {message.sources && message.sources.length > 0 && (
                <div className="mt-4 border-t border-gray-600 pt-2">
                    <p className="text-xs font-semibold text-gray-400 mb-2">Sources:</p>
                    <ul className="space-y-1">
                        {message.sources.map((source, index) => (
                            <li key={index}>
                                <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-400 hover:underline break-all">
                                    {index + 1}. {source.title || source.uri}
                                </a>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    </div>
);


const ChatView: React.FC = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const chatRef = useRef<Chat | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const [positiveMessage, setPositiveMessage] = useState('');

    useEffect(() => {
        chatRef.current = startChat();
        setMessages([{
            role: Role.AI,
            text: "Hello! I'm HOAY AI. How can I help you today? You can ask me for news, to fact-check something, or just have a chat."
        }]);
        setPositiveMessage(POSITIVE_MESSAGES[Math.floor(Math.random() * POSITIVE_MESSAGES.length)]);
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isLoading]);

    const handleSend = async () => {
        if (!input.trim() || isLoading) return;

        const userMessage: ChatMessage = { role: Role.USER, text: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        const aiResponse: ChatMessage = { role: Role.AI, text: '', sources: [] };
        setMessages(prev => [...prev, aiResponse]);
        
        const isGroundedQuery = /news|latest|update|fact-check|fact check|true that|what is/i.test(input);
        
        try {
            const stream = isGroundedQuery 
                ? await getGroundedResponseStream(input)
                : await sendMessageStream(chatRef.current!, input);

            let fullResponseText = "";
            let finalResponse: GenerateContentResponse | null = null;

            for await (const chunk of stream) {
                fullResponseText += chunk.text;
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1].text = fullResponseText;
                    return newMessages;
                });
                if('candidates' in chunk) {
                   finalResponse = chunk;
                }
            }
            if (finalResponse && isGroundedQuery) {
                const sources = extractSources(finalResponse);
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1].sources = sources;
                    return newMessages;
                });
            }

        } catch (error) {
            console.error("Error sending message:", error);
            setMessages(prev => {
                const newMessages = [...prev];
                newMessages[newMessages.length - 1].text = "I'm sorry, I encountered an error. Please try again.";
                return newMessages;
            });
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="flex-1 flex flex-col bg-gray-900 p-4 overflow-hidden">
             <div className="mb-4 p-4 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg shadow-lg text-center">
                <p className="text-sm italic text-gray-200">{positiveMessage}</p>
            </div>
            <div id="chat-window" className="flex-1 overflow-y-auto pr-2">
                {messages.map((msg, index) => {
                    switch (msg.role) {
                        case Role.USER:
                            return <UserMessage key={index} text={msg.text} />;
                        case Role.AI:
                            return <AiMessage key={index} message={msg} />;
                        default:
                            return null;
                    }
                })}
                {isLoading && messages[messages.length-1].role === Role.AI && (
                    <div className="flex justify-start mb-4">
                       <div className="ml-2 py-3 px-4 bg-gray-700 rounded-br-3xl rounded-tr-3xl rounded-tl-xl text-gray-200">
                           <div className="flex items-center space-x-2">
                               <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse delay-75"></div>
                               <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse delay-150"></div>
                               <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse delay-300"></div>
                           </div>
                       </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>
            <div className="mt-4 flex-shrink-0">
                <div className="flex items-center bg-gray-800 rounded-lg p-2 shadow-inner">
                    <input
                        type="text"
                        className="flex-grow bg-transparent text-white placeholder-gray-500 focus:outline-none px-2"
                        placeholder="Type your message..."
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                        disabled={isLoading}
                    />
                    <button
                        onClick={handleSend}
                        disabled={isLoading}
                        className="p-2 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-transform duration-200 hover:scale-110"
                    >
                        <SendIcon />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ChatView;
