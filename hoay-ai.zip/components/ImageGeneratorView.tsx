
import React, { useState } from 'react';
import { generateImage } from '../services/geminiService';

const Spinner: React.FC = () => (
    <div className="border-4 border-gray-500 border-t-blue-500 rounded-full w-12 h-12 animate-spin"></div>
);

const ImageGeneratorView: React.FC = () => {
    const [prompt, setPrompt] = useState('');
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleGenerate = async () => {
        if (!prompt.trim()) {
            setError('Please enter a description for the image.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setImageUrl(null);

        try {
            const url = await generateImage(prompt);
            setImageUrl(url);
        } catch (err: any) {
            setError(err.message || 'An unexpected error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="flex-1 flex flex-col items-center justify-center bg-gray-900 p-8 text-white overflow-y-auto">
            <div className="w-full max-w-3xl text-center">
                <h2 className="text-4xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
                    AI Image Creator
                </h2>
                <p className="text-gray-400 mb-8">Describe the image you want to create, and let AI bring it to life.</p>
                
                <div className="flex flex-col sm:flex-row gap-4 mb-8">
                    <input
                        type="text"
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="e.g., A happy senior couple gardening on a sunny day"
                        className="flex-grow bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                    />
                    <button
                        onClick={handleGenerate}
                        disabled={isLoading}
                        className="bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold py-3 px-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-wait"
                    >
                        {isLoading ? 'Generating...' : 'Generate Image'}
                    </button>
                </div>

                {error && <p className="text-red-400 mb-4">{error}</p>}

                <div className="w-full aspect-video bg-gray-800 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-700">
                    {isLoading ? (
                        <Spinner />
                    ) : imageUrl ? (
                        <img src={imageUrl} alt={prompt} className="w-full h-full object-contain rounded-lg" />
                    ) : (
                        <p className="text-gray-500">Your generated image will appear here</p>
                    )}
                </div>
                 {imageUrl && !isLoading && (
                    <a
                        href={imageUrl}
                        download={`hoay-ai-image-${Date.now()}.jpg`}
                        className="mt-6 inline-block bg-green-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-green-700 transition-colors"
                    >
                        Download Image
                    </a>
                )}
            </div>
        </div>
    );
};

export default ImageGeneratorView;
