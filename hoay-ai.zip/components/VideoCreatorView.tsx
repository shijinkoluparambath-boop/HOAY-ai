import React, { useState } from 'react';
import { generateVideoScript, generateImage } from '../services/geminiService';
import { VideoIcon } from './Icons';

const Spinner: React.FC = () => (
    <div className="border-4 border-gray-500 border-t-blue-500 rounded-full w-12 h-12 animate-spin"></div>
);

interface Scene {
    description: string;
    imageUrl: string | null;
}

const VideoCreatorView: React.FC = () => {
    const [story, setStory] = useState('');
    const [scenes, setScenes] = useState<Scene[]>([]);
    const [currentSceneIndex, setCurrentSceneIndex] = useState(0);
    const [isLoading, setIsLoading] = useState(false);
    const [loadingStatus, setLoadingStatus] = useState('');
    const [error, setError] = useState<string | null>(null);

    const handleGenerate = async () => {
        if (!story.trim()) {
            setError('Please enter a story or a concept.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setScenes([]);
        
        try {
            setLoadingStatus('Creating a script from your story...');
            const sceneDescriptions = await generateVideoScript(story);
            
            if (sceneDescriptions.length === 0) {
                throw new Error("The AI couldn't create any scenes from your story. Try being more descriptive.");
            }

            const initialScenes = sceneDescriptions.map(desc => ({ description: desc, imageUrl: null }));
            setScenes(initialScenes);

            for (let i = 0; i < sceneDescriptions.length; i++) {
                setLoadingStatus(`Generating image for scene ${i + 1} of ${sceneDescriptions.length}...`);
                const imageUrl = await generateImage(sceneDescriptions[i]);
                setScenes(prevScenes => {
                    const newScenes = [...prevScenes];
                    newScenes[i].imageUrl = imageUrl;
                    return newScenes;
                });
            }
            setCurrentSceneIndex(0);

        } catch (err: any) {
            setError(err.message || 'An unexpected error occurred during video creation.');
        } finally {
            setIsLoading(false);
            setLoadingStatus('');
        }
    };

    const goToNextScene = () => {
        setCurrentSceneIndex(prev => (prev + 1) % scenes.length);
    };

    const goToPrevScene = () => {
        setCurrentSceneIndex(prev => (prev - 1 + scenes.length) % scenes.length);
    };

    const isGenerated = scenes.length > 0 && scenes.every(s => s.imageUrl);

    return (
        <div className="flex-1 flex flex-col items-center justify-center bg-gray-900 p-8 text-white overflow-y-auto">
            <div className="w-full max-w-4xl text-center">
                <h2 className="text-4xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
                    AI Video Creator
                </h2>
                <p className="text-gray-400 mb-8">Turn your stories into visual narratives. Describe a story, and watch it come to life.</p>
                
                {!isGenerated && (
                    <div className="w-full">
                        <textarea
                            value={story}
                            onChange={(e) => setStory(e.target.value)}
                            placeholder="e.g., A wise old owl teaches a young squirrel about the magic of the forest. They visit glowing mushrooms and sparkling streams."
                            className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all h-32 resize-none"
                            rows={4}
                        />
                        <button
                            onClick={handleGenerate}
                            disabled={isLoading}
                            className="mt-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-wait w-full sm:w-auto"
                        >
                            {isLoading ? 'Creating...' : 'Generate Video'}
                        </button>
                    </div>
                )}

                {error && <p className="text-red-400 mt-4">{error}</p>}

                <div className="w-full aspect-video bg-gray-800 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-700 mt-8">
                    {isLoading ? (
                        <div className="flex flex-col items-center gap-4">
                            <Spinner />
                            <p className="text-gray-400">{loadingStatus}</p>
                        </div>
                    ) : isGenerated ? (
                        <div className="w-full h-full flex flex-col relative">
                           <img src={scenes[currentSceneIndex].imageUrl!} alt={scenes[currentSceneIndex].description} className="w-full h-full object-contain rounded-lg" />
                           <div className="absolute bottom-0 left-0 right-0 bg-black/60 p-4 rounded-b-lg">
                                <p className="text-sm md:text-base text-center text-gray-200">{scenes[currentSceneIndex].description}</p>
                           </div>
                           <button onClick={goToPrevScene} className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full hover:bg-black/80 transition-colors">
                            &#10094;
                           </button>
                            <button onClick={goToNextScene} className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full hover:bg-black/80 transition-colors">
                            &#10095;
                           </button>
                           <div className="absolute top-2 right-2 bg-black/50 px-3 py-1 rounded-full text-xs">
                                Scene {currentSceneIndex + 1} / {scenes.length}
                           </div>
                        </div>
                    ) : (
                        <div className="flex flex-col items-center gap-3 text-gray-500">
                             <VideoIcon className="w-16 h-16"/>
                            <p>Your generated video will appear here</p>
                        </div>
                    )}
                </div>
                 {isGenerated && (
                    <button
                        onClick={() => { setScenes([]); setStory(''); }}
                        className="mt-6 bg-gray-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-gray-700 transition-colors"
                    >
                        Create Another Video
                    </button>
                )}
            </div>
        </div>
    );
};

export default VideoCreatorView;
