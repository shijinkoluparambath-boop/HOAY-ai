
import React, { useState, useEffect, useCallback } from 'react';
import type { Reminder } from '../types';
import { ReminderIcon } from './Icons';

const RemindersView: React.FC = () => {
    const [reminders, setReminders] = useState<Reminder[]>([]);
    const [newReminder, setNewReminder] = useState('');

    useEffect(() => {
        try {
            const storedReminders = localStorage.getItem('hoay-ai-reminders');
            if (storedReminders) {
                setReminders(JSON.parse(storedReminders));
            }
        } catch (error) {
            console.error("Failed to load reminders from localStorage", error);
        }
    }, []);

    const saveReminders = useCallback((updatedReminders: Reminder[]) => {
        try {
            localStorage.setItem('hoay-ai-reminders', JSON.stringify(updatedReminders));
        } catch (error) {
            console.error("Failed to save reminders to localStorage", error);
        }
    }, []);

    const handleAddReminder = () => {
        if (newReminder.trim() === '') return;
        const updatedReminders = [
            ...reminders,
            { id: Date.now(), text: newReminder, completed: false }
        ];
        setReminders(updatedReminders);
        saveReminders(updatedReminders);
        setNewReminder('');
    };
    
    const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            handleAddReminder();
        }
    };

    const toggleReminder = (id: number) => {
        const updatedReminders = reminders.map(r =>
            r.id === id ? { ...r, completed: !r.completed } : r
        );
        setReminders(updatedReminders);
        saveReminders(updatedReminders);
    };

    const deleteReminder = (id: number) => {
        const updatedReminders = reminders.filter(r => r.id !== id);
        setReminders(updatedReminders);
        saveReminders(updatedReminders);
    };

    return (
        <div className="flex-1 flex flex-col bg-gray-900 p-8 text-white overflow-y-auto">
            <div className="w-full max-w-3xl mx-auto">
                <div className="flex items-center gap-4 mb-8">
                    <div className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg">
                        <ReminderIcon className="w-8 h-8"/>
                    </div>
                    <div>
                        <h2 className="text-4xl font-bold">Daily Reminders</h2>
                        <p className="text-gray-400">Stay on top of your tasks and medications.</p>
                    </div>
                </div>

                <div className="flex gap-4 mb-8">
                    <input
                        type="text"
                        value={newReminder}
                        onChange={(e) => setNewReminder(e.target.value)}
                        onKeyPress={handleKeyPress}
                        placeholder="e.g., Take morning pills at 8 AM"
                        className="flex-grow bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                    />
                    <button
                        onClick={handleAddReminder}
                        className="bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold py-3 px-6 rounded-lg shadow-lg hover:shadow-xl transition-all"
                    >
                        Add
                    </button>
                </div>

                <div className="space-y-4">
                    {reminders.length > 0 ? (
                        reminders.map(reminder => (
                            <div
                                key={reminder.id}
                                className={`flex items-center justify-between p-4 rounded-lg transition-all duration-300 ${
                                    reminder.completed ? 'bg-gray-800 opacity-60' : 'bg-gray-700'
                                }`}
                            >
                                <div className="flex items-center gap-4">
                                    <input
                                        type="checkbox"
                                        checked={reminder.completed}
                                        onChange={() => toggleReminder(reminder.id)}
                                        className="h-6 w-6 rounded-md border-gray-500 text-blue-500 bg-gray-800 focus:ring-blue-600 cursor-pointer"
                                    />
                                    <span className={`text-lg ${reminder.completed ? 'line-through text-gray-500' : 'text-gray-200'}`}>
                                        {reminder.text}
                                    </span>
                                </div>
                                <button
                                    onClick={() => deleteReminder(reminder.id)}
                                    className="text-gray-500 hover:text-red-500 transition-colors"
                                    aria-label="Delete reminder"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>
                        ))
                    ) : (
                        <div className="text-center py-12 border-2 border-dashed border-gray-700 rounded-lg">
                            <p className="text-gray-500">You have no reminders set.</p>
                            <p className="text-gray-600 text-sm">Use the input above to add one!</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default RemindersView;
