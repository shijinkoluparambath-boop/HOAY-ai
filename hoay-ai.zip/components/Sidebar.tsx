import React from 'react';
import { View } from '../types';
import { ChatIcon, ImageIcon, ReminderIcon, VideoIcon } from './Icons';

interface SidebarProps {
  activeView: View;
  setActiveView: (view: View) => void;
}

const NavItem: React.FC<{
  icon: React.ReactNode;
  label: View;
  isActive: boolean;
  onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center w-full px-4 py-3 text-left transition-colors duration-200 rounded-lg ${
      isActive
        ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
        : 'text-gray-400 hover:bg-gray-700 hover:text-white'
    }`}
  >
    {icon}
    <span className="ml-4 text-sm font-medium">{label}</span>
  </button>
);

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView }) => {
  return (
    <aside className="w-64 flex-shrink-0 bg-gray-800 p-4 flex flex-col justify-between">
      <div>
        <div className="flex items-center mb-8">
          <div className="p-2 rounded-lg bg-gradient-to-tr from-pink-500 via-red-500 to-yellow-500">
             <div className="text-white font-bold text-xl">H</div>
          </div>
          <h1 className="text-2xl font-bold ml-3 tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">HOAY AI</h1>
        </div>
        <nav className="space-y-2">
          <NavItem
            icon={<ChatIcon />}
            label={View.CHAT}
            isActive={activeView === View.CHAT}
            onClick={() => setActiveView(View.CHAT)}
          />
          <NavItem
            icon={<ImageIcon />}
            label={View.IMAGE}
            isActive={activeView === View.IMAGE}
            onClick={() => setActiveView(View.IMAGE)}
          />
          <NavItem
            icon={<VideoIcon />}
            label={View.VIDEO}
            isActive={activeView === View.VIDEO}
            onClick={() => setActiveView(View.VIDEO)}
          />
          <NavItem
            icon={<ReminderIcon />}
            label={View.REMINDERS}
            isActive={activeView === View.REMINDERS}
            onClick={() => setActiveView(View.REMINDERS)}
          />
        </nav>
      </div>
       <div className="text-xs text-gray-500 text-center">
        Your positive digital companion.
        <br />
        &copy; {new Date().getFullYear()}
      </div>
    </aside>
  );
};

export default Sidebar;