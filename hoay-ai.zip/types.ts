export enum Role {
  USER = 'user',
  AI = 'ai',
  SYSTEM = 'system',
}

export interface ChatMessage {
  role: Role;
  text: string;
  sources?: GroundingSource[];
}

export interface Reminder {
  id: number;
  text: string;
  completed: boolean;
}

export enum View {
  CHAT = 'Chat',
  IMAGE = 'Image Creator',
  VIDEO = 'Video Creator',
  REMINDERS = 'Reminders',
}

export interface GroundingSource {
    uri: string;
    title: string;
}
