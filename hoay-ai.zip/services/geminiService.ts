import { GoogleGenAI, Chat, GenerateContentResponse, Type } from "@google/genai";
import type { GroundingSource } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const chatConfig = {
    systemInstruction: `You are HOAY AI, a friendly and helpful AI assistant for senior citizens. Your personality is warm, patient, and encouraging.
    - For general conversation, be a pleasant companion.
    - For health, news, or factual questions, state that you are using Google Search to find the latest information and always be helpful.
    - When asked to write an article, create a well-structured and easy-to-read piece on the requested topic.
    - Your goal is to be a trustworthy and positive source of information and companionship.`,
};

export const startChat = (): Chat => {
    return ai.chats.create({
        model: 'gemini-2.5-flash',
        config: chatConfig,
    });
};

export const sendMessageStream = async (chat: Chat, message: string) => {
    return chat.sendMessageStream({ message });
};

export const getGroundedResponseStream = async (message: string) => {
    return ai.models.generateContentStream({
        model: 'gemini-2.5-flash',
        contents: message,
        config: {
            tools: [{ googleSearch: {} }],
        },
    });
};

export const extractSources = (response: GenerateContentResponse): GroundingSource[] => {
    const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
    if (!groundingMetadata?.groundingChunks) {
        return [];
    }

    const sources: GroundingSource[] = groundingMetadata.groundingChunks
        .map((chunk: any) => ({
            uri: chunk.web?.uri || '',
            title: chunk.web?.title || 'Untitled',
        }))
        .filter(source => source.uri);
        
    // Deduplicate sources based on URI
    const uniqueSources = Array.from(new Map(sources.map(item => [item['uri'], item])).values());
    
    return uniqueSources;
};


export const generateImage = async (prompt: string): Promise<string> => {
    try {
        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: `A vibrant, high-quality, photorealistic image: ${prompt}`,
            config: {
              numberOfImages: 1,
              outputMimeType: 'image/jpeg',
              aspectRatio: '16:9',
            },
        });

        if (response.generatedImages && response.generatedImages.length > 0) {
            const base64ImageBytes = response.generatedImages[0].image.imageBytes;
            return `data:image/jpeg;base64,${base64ImageBytes}`;
        } else {
            throw new Error("No image was generated.");
        }
    } catch (error) {
        console.error("Error generating image:", error);
        throw new Error("Failed to generate image. Please try again.");
    }
};

export const generateVideoScript = async (story: string): Promise<string[]> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Based on the following story, break it down into 4 to 6 distinct visual scenes. For each scene, provide a short, descriptive sentence perfect for an AI image generator. Story: "${story}"`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        scenes: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.STRING,
                                description: 'A short, descriptive sentence for a scene.'
                            }
                        }
                    }
                },
            },
        });
        
        const jsonText = response.text.trim();
        const result = JSON.parse(jsonText);
        
        if (result && Array.isArray(result.scenes)) {
            return result.scenes;
        } else {
            throw new Error("Invalid script format received from AI.");
        }

    } catch (error) {
        console.error("Error generating video script:", error);
        throw new Error("Failed to generate a script from the story.");
    }
};
